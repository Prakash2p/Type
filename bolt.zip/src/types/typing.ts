export interface TypingState {
  text: string;
  currentIndex: number;
  mistakes: number;
  startTime: number | null;
  endTime: number | null;
  isComplete: boolean;
  wpm: number;
  accuracy: number;
  mode: 'words' | 'time' | 'quote';
  timeLimit: number;
  wordCount: number;
  theme: 'light' | 'dark';
  soundEnabled: boolean;
  language: string;
  history: TypingStats[];
}

export interface TypingStats {
  wpm: number;
  accuracy: number;
  mistakes: number;
  time: number;
  date: string;
  mode: string;
}

export interface Quote {
  text: string;
  author: string;
}