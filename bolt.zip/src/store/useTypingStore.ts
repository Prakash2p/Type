import { create } from 'zustand';
import { TypingState } from '../types/typing';
import { generateRandomWords, quotes } from '../utils/texts';

interface TypingStore extends TypingState {
  setText: (text: string) => void;
  updateIndex: (index: number) => void;
  incrementMistakes: () => void;
  startTyping: () => void;
  completeTyping: () => void;
  resetTyping: () => void;
  setMode: (mode: 'words' | 'time' | 'quote') => void;
  setTimeLimit: (seconds: number) => void;
  setWordCount: (count: number) => void;
  toggleTheme: () => void;
  toggleSound: () => void;
  setLanguage: (lang: string) => void;
}

const initialState: TypingState = {
  text: 'Start typing this sample text to begin your practice session.',
  currentIndex: 0,
  mistakes: 0,
  startTime: null,
  endTime: null,
  isComplete: false,
  wpm: 0,
  accuracy: 100,
  mode: 'words',
  timeLimit: 30,
  wordCount: 25,
  theme: 'light',
  soundEnabled: true,
  language: 'en',
  history: []
};

export const useTypingStore = create<TypingStore>((set) => ({
  ...initialState,
  setText: (text) => set({ text }),
  updateIndex: (index) => set({ currentIndex: index }),
  incrementMistakes: () => set((state) => ({ mistakes: state.mistakes + 1 })),
  startTyping: () => set({ startTime: Date.now() }),
  completeTyping: () => {
    const endTime = Date.now();
    set((state) => {
      const timeInMinutes = (endTime - (state.startTime || 0)) / 60000;
      const wordsTyped = state.text.split(' ').length;
      const wpm = Math.round(wordsTyped / timeInMinutes);
      const accuracy = Math.max(0, Math.round(100 - (state.mistakes / state.text.length) * 100));
      
      const newStats = {
        wpm,
        accuracy,
        mistakes: state.mistakes,
        time: endTime - (state.startTime || 0),
        date: new Date().toISOString(),
        mode: state.mode
      };

      return {
        endTime,
        isComplete: true,
        wpm,
        accuracy,
        history: [...state.history, newStats]
      };
    });
  },
  resetTyping: () => {
    const newText = initialState.mode === 'quote'
      ? quotes[Math.floor(Math.random() * quotes.length)].text
      : generateRandomWords(initialState.wordCount);
    
    set({
      ...initialState,
      text: newText
    });
  },
  setMode: (mode) => set({ mode }),
  setTimeLimit: (seconds) => set({ timeLimit: seconds }),
  setWordCount: (count) => set({ wordCount: count }),
  toggleTheme: () => set((state) => ({ 
    theme: state.theme === 'light' ? 'dark' : 'light' 
  })),
  toggleSound: () => set((state) => ({ 
    soundEnabled: !state.soundEnabled 
  })),
  setLanguage: (language) => set({ language })
}));