import React from 'react';
import { Settings, Moon, Sun, Volume2, VolumeX } from 'lucide-react';
import { useTypingStore } from '../store/useTypingStore';

export const Header: React.FC = () => {
  const { theme, soundEnabled, toggleTheme, toggleSound } = useTypingStore();

  return (
    <header className="w-full py-4 px-6 flex justify-between items-center bg-white dark:bg-gray-800 shadow-sm">
      <div className="text-2xl font-bold text-gray-800 dark:text-white">
        TypeMaster
      </div>
      <div className="flex items-center gap-4">
        <button
          onClick={toggleSound}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          {soundEnabled ? (
            <Volume2 className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          ) : (
            <VolumeX className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          )}
        </button>
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          {theme === 'dark' ? (
            <Sun className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          ) : (
            <Moon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          )}
        </button>
        <button className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
          <Settings className="w-5 h-5 text-gray-600 dark:text-gray-300" />
        </button>
      </div>
    </header>
  );
};