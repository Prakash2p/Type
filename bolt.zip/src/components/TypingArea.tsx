import React, { useEffect, useCallback } from 'react';
import { useTypingStore } from '../store/useTypingStore';

export const TypingArea: React.FC = () => {
  const { 
    text, 
    currentIndex, 
    startTime,
    isComplete,
    updateIndex, 
    incrementMistakes,
    startTyping,
    completeTyping 
  } = useTypingStore();

  const handleKeyPress = useCallback((e: KeyboardEvent) => {
    if (isComplete) return;

    if (!startTime) {
      startTyping();
    }

    if (e.key === text[currentIndex]) {
      updateIndex(currentIndex + 1);
      if (currentIndex + 1 === text.length) {
        completeTyping();
      }
    } else {
      incrementMistakes();
    }
  }, [currentIndex, text, startTime, isComplete]);

  useEffect(() => {
    window.addEventListener('keypress', handleKeyPress);
    return () => window.removeEventListener('keypress', handleKeyPress);
  }, [handleKeyPress]);

  return (
    <div className="w-full max-w-3xl p-6 bg-white rounded-lg shadow-lg">
      <div className="text-lg leading-relaxed font-mono">
        {text.split('').map((char, index) => (
          <span
            key={index}
            className={`${
              index === currentIndex
                ? 'bg-blue-200 animate-pulse'
                : index < currentIndex
                ? 'text-green-600'
                : 'text-gray-800'
            }`}
          >
            {char}
          </span>
        ))}
      </div>
    </div>
  );
};