import React from 'react';
import { Timer, Type, Target } from 'lucide-react';
import { useTypingStore } from '../store/useTypingStore';

export const Stats: React.FC = () => {
  const { wpm, accuracy, mistakes, isComplete } = useTypingStore();

  return (
    <div className="flex gap-8 p-4 bg-white rounded-lg shadow-md">
      <div className="flex items-center gap-2">
        <Type className="w-5 h-5 text-blue-500" />
        <div>
          <p className="text-sm text-gray-600">WPM</p>
          <p className="font-bold">{isComplete ? wpm : '--'}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Target className="w-5 h-5 text-green-500" />
        <div>
          <p className="text-sm text-gray-600">Accuracy</p>
          <p className="font-bold">{isComplete ? `${accuracy}%` : '--'}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Timer className="w-5 h-5 text-red-500" />
        <div>
          <p className="text-sm text-gray-600">Mistakes</p>
          <p className="font-bold">{mistakes}</p>
        </div>
      </div>
    </div>
  );
};