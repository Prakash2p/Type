import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { useTypingStore } from '../store/useTypingStore';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export const ProgressChart: React.FC = () => {
  const { history } = useTypingStore();

  const data = {
    labels: history.map((_, index) => `Test ${index + 1}`),
    datasets: [
      {
        label: 'WPM',
        data: history.map(stat => stat.wpm),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
      },
      {
        label: 'Accuracy',
        data: history.map(stat => stat.accuracy),
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.5)',
      }
    ]
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Your Progress'
      }
    }
  };

  return (
    <div className="w-full max-w-3xl p-6 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
      <Line options={options} data={data} />
    </div>
  );
};