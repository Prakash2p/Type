import React from 'react';
import { Clock, Type, Quote } from 'lucide-react';
import { useTypingStore } from '../store/useTypingStore';
import clsx from 'clsx';

export const ModeSelector: React.FC = () => {
  const { mode, setMode, timeLimit, setTimeLimit, wordCount, setWordCount } = useTypingStore();

  const buttonClass = (active: boolean) =>
    clsx(
      'flex items-center gap-2 px-4 py-2 rounded-lg transition-colors',
      active
        ? 'bg-blue-600 text-white'
        : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300'
    );

  return (
    <div className="flex flex-col gap-4">
      <div className="flex gap-2">
        <button
          className={buttonClass(mode === 'time')}
          onClick={() => setMode('time')}
        >
          <Clock className="w-4 h-4" />
          Time
        </button>
        <button
          className={buttonClass(mode === 'words')}
          onClick={() => setMode('words')}
        >
          <Type className="w-4 h-4" />
          Words
        </button>
        <button
          className={buttonClass(mode === 'quote')}
          onClick={() => setMode('quote')}
        >
          <Quote className="w-4 h-4" />
          Quote
        </button>
      </div>

      {mode === 'time' && (
        <div className="flex gap-2">
          {[15, 30, 60].map((seconds) => (
            <button
              key={seconds}
              className={buttonClass(timeLimit === seconds)}
              onClick={() => setTimeLimit(seconds)}
            >
              {seconds}s
            </button>
          ))}
        </div>
      )}

      {mode === 'words' && (
        <div className="flex gap-2">
          {[10, 25, 50].map((count) => (
            <button
              key={count}
              className={buttonClass(wordCount === count)}
              onClick={() => setWordCount(count)}
            >
              {count} words
            </button>
          ))}
        </div>
      )}
    </div>
  );
};