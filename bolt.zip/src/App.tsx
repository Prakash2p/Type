import React, { useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { TypingArea } from './components/TypingArea';
import { Stats } from './components/Stats';
import { ModeSelector } from './components/ModeSelector';
import { ProgressChart } from './components/ProgressChart';
import { useTypingStore } from './store/useTypingStore';
import { Toaster } from 'react-hot-toast';

function App() {
  const { theme } = useTypingStore();

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 transition-colors">
      <Toaster position="top-right" />
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8 flex flex-col items-center gap-8">
        <ModeSelector />
        <Stats />
        <TypingArea />
        <ProgressChart />
      </main>

      <Footer />
    </div>
  );
}

export default App;